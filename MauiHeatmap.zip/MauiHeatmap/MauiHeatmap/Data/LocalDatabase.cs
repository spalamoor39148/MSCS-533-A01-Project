using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using SQLite;
using MauiHeatmap.Models;

namespace MauiHeatmap.Data
{
    public class LocalDatabase
    {
        private readonly SQLiteAsyncConnection _db;

        public LocalDatabase(string dbPath)
        {
            _db = new SQLiteAsyncConnection(dbPath);
            _db.CreateTableAsync<LocationEntry>().Wait();
        }

        public Task<int> AddLocationAsync(LocationEntry entry) =>
            _db.InsertAsync(entry);

        public Task<List<LocationEntry>> GetAllLocationsAsync() =>
            _db.Table<LocationEntry>().OrderByDescending(e => e.TimestampUtc).ToListAsync();

        public Task<int> DeleteAllAsync() =>
            _db.DeleteAllAsync<LocationEntry>();
    }
}
