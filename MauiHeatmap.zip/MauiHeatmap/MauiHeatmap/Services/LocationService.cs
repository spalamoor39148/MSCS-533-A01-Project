using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Maui.Devices.Sensors;
using Microsoft.Maui.ApplicationModel;
using MauiHeatmap.Data;
using MauiHeatmap.Models;

namespace MauiHeatmap.Services
{
    public class LocationService
    {
        private readonly LocalDatabase _db;
        private CancellationTokenSource? _cts;
        private bool _isRunning = false;

        public LocationService(LocalDatabase db)
        {
            _db = db;
        }

        public bool IsRunning => _isRunning;

        public async Task StartAsync(int samplingIntervalSeconds = 5)
        {
            if (_isRunning) return;
            _isRunning = true;

            var status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
            if (status != PermissionStatus.Granted)
            {
                _isRunning = false;
                return;
            }

            _cts = new CancellationTokenSource();
            var token = _cts.Token;

            _ = Task.Run(async () =>
            {
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        var request = new GeolocationRequest(GeolocationAccuracy.Best, TimeSpan.FromSeconds(10));
                        var location = await Geolocation.GetLocationAsync(request);
                        if (location != null)
                        {
                            var entry = new LocationEntry
                            {
                                Latitude = location.Latitude,
                                Longitude = location.Longitude,
                                TimestampUtc = DateTime.UtcNow
                            };
                            await _db.AddLocationAsync(entry);
                        }
                    }
                    catch (Exception)
                    {
                    }

                    try
                    {
                        await Task.Delay(TimeSpan.FromSeconds(samplingIntervalSeconds), token);
                    }
                    catch (TaskCanceledException)
                    {
                        break;
                    }
                }
            }, token);
        }

        public void Stop()
        {
            if (!_isRunning) return;
            _cts?.Cancel();
            _cts?.Dispose();
            _isRunning = false;
        }
    }
}
