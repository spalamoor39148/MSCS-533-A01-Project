using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Maui.Maps;
using Microsoft.Maui.Graphics;
using MauiHeatmap.Models;

namespace MauiHeatmap.Services
{
    public class HeatmapService
    {
        public IEnumerable<MapCircle> BuildHeatmapCircles(IEnumerable<LocationEntry> points,
                                                           double radiusMeters = 60,
                                                           double densityRadiusMeters = 80)
        {
            if (points == null) yield break;

            var pts = points.ToList();

            for (int i = 0; i < pts.Count; i++)
            {
                var p = pts[i];
                var nearby = pts.Count(q => DistanceMeters(p.Latitude, p.Longitude, q.Latitude, q.Longitude) <= densityRadiusMeters);

                var alpha = Math.Min(0.85, 0.15 + (nearby / 10.0));
                var scale = Math.Min(2.5, 1.0 + (nearby / 6.0));

                var circle = new MapCircle
                {
                    Center = new Location(p.Latitude, p.Longitude),
                    Radius = Distance.FromMeters(radiusMeters * scale),
                    StrokeColor = Color.FromRgba(255, 0, 0, (float)alpha),
                    StrokeWidth = 0,
                    FillColor = Color.FromRgba(255, 0, 0, (float)(alpha * 0.6))
                };

                yield return circle;
            }
        }

        private static double DistanceMeters(double lat1, double lon1, double lat2, double lon2)
        {
            const double R = 6371000;
            var dLat = DegreesToRadians(lat2 - lat1);
            var dLon = DegreesToRadians(lon2 - lon1);

            var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                    Math.Cos(DegreesToRadians(lat1)) * Math.Cos(DegreesToRadians(lat2)) *
                    Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

            var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            return R * c;
        }

        private static double DegreesToRadians(double deg) => deg * Math.PI / 180.0;
    }
}
