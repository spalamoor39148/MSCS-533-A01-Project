using Microsoft.Maui.Controls;
using Microsoft.Extensions.DependencyInjection;
using MauiHeatmap.Data;
using MauiHeatmap.Views;

namespace MauiHeatmap;

public partial class App : Application
{
    public App(IServiceProvider serviceProvider)
    {
        InitializeComponent();
        MainPage = serviceProvider.GetRequiredService<MainPage>();
    }
}
