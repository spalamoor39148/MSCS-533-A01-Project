using System;
using System.Linq;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Maps;
using MauiHeatmap.Data;
using MauiHeatmap.Services;

namespace MauiHeatmap.Views
{
    public partial class MainPage : ContentPage
    {
        private readonly LocalDatabase _database;
        private readonly LocationService _locationService;
        private readonly HeatmapService _heatmapService;

        public MainPage(LocalDatabase db)
        {
            InitializeComponent();

            _database = db;
            _locationService = new LocationService(_database);
            _heatmapService = new HeatmapService();

            MainMap.MoveToRegion(MapSpan.FromCenterAndRadius(new Location(37.3861, -122.0839), Distance.FromMiles(1)));
        }

        private async void StartButton_Clicked(object sender, EventArgs e)
        {
            StartButton.IsEnabled = false;
            StopButton.IsEnabled = true;
            StatusLabel.Text = "Status: Tracking...";
            await _locationService.StartAsync(samplingIntervalSeconds: 5);
        }

        private void StopButton_Clicked(object sender, EventArgs e)
        {
            _locationService.Stop();
            StartButton.IsEnabled = true;
            StopButton.IsEnabled = false;
            StatusLabel.Text = "Status: Stopped";
        }

        private async void RefreshButton_Clicked(object sender, EventArgs e)
        {
            await RefreshMapAsync();
        }

        private async void ClearButton_Clicked(object sender, EventArgs e)
        {
            await _database.DeleteAllAsync();
            MainMap.MapElements.Clear();
            MainMap.Pins.Clear();
            StatusLabel.Text = "Status: Data cleared";
        }

        private async System.Threading.Tasks.Task RefreshMapAsync()
        {
            var points = await _database.GetAllLocationsAsync();

            MainMap.MapElements.Clear();
            MainMap.Pins.Clear();

            if (points == null || !points.Any())
            {
                StatusLabel.Text = "Status: No data to render.";
                return;
            }

            var circles = _heatmapService.BuildHeatmapCircles(points, radiusMeters: 40, densityRadiusMeters: 80);
            foreach (var c in circles)
                MainMap.MapElements.Add(c);

            var recent = points.OrderByDescending(p => p.TimestampUtc).Take(3).ToList();
            foreach (var r in recent)
            {
                MainMap.Pins.Add(new Pin { Label = r.TimestampUtc.ToLocalTime().ToString("g"), Location = new Location(r.Latitude, r.Longitude) });
            }

            var last = points.OrderByDescending(p => p.TimestampUtc).First();
            MainMap.MoveToRegion(MapSpan.FromCenterAndRadius(new Location(last.Latitude, last.Longitude), Distance.FromMeters(800)));

            StatusLabel.Text = $"Status: Rendered {points.Count} points";
        }
    }
}
