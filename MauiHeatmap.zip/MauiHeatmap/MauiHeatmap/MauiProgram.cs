using Microsoft.Extensions.DependencyInjection;
using Microsoft.Maui;
using Microsoft.Maui.Controls.Hosting;
using Microsoft.Maui.Hosting;
using System.IO;
using MauiHeatmap.Data;
using Microsoft.Maui.Controls;
using System;

namespace MauiHeatmap;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();

        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
            });

        // Add Maps support
        builder.Services.AddMauiMaps();

        // Database path
        var dbPath = Path.Combine(FileSystem.AppDataDirectory, "maui_heatmap.db3");
        var localDb = new LocalDatabase(dbPath);

        // Register services and pages in DI container
        builder.Services.AddSingleton(localDb);
        builder.Services.AddSingleton<Views.MainPage>();

        return builder.Build();
    }
}
